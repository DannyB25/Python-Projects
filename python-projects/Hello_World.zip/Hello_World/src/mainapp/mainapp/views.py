from django.http import HttpResponse
from django.shortcuts import render

def home(request):
    user = request.user
    context = {
        'user': user,
    }

    names = ["Susan", "Molly", "Jeremy", "Trinity", "Mikaela", "Joshua", "Mary"]
    context = {
        'names': names,
    }
    return render(request, "home.html", context) #this returns request, home.html and context variable
