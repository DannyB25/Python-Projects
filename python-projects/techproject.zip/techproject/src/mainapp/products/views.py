from lib2to3.fixes.fix_input import context

from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from products.models import Product
from .forms import ProductForm
from .models import Product

# Create your views here.
def admin_console(request):
    products = Product.objects.all()
    return render(request, 'products/products_page.html', {'products': products})

def details(request, pk):
    pk = int(pk)
    item = get_object_or_404(Product, pk=pk)
    form = ProductForm(data=request.POST or None, instance=item)
    if request.method == 'POST':
        if form.is_valid():
            form2 = form.save(commit=False)
            form2.save()
            return redirect('admin_console')
        else:
            print(form.errors)
    else:
        return render(request, 'products/present_product.html', {'form': form})

def delete (request, pk): #delete function, take request and primary key
    pk = int(pk) #making sure pk is an integery
    item = get_object_or_404(Product, pk=pk) #access product database, pass in primary key so we can get the info from those items
    if request.method == 'POST': #if the user submits delete
        item.delete() #delete item
        return redirect('admin_console') #then return to admin console
    context = {'item': item} #otherwise take the item and make a dictionary
    return render(request, "products/confirmDelete.html", context) #send back the request to products/confirmDelete.html page with context variable info

def confirmed(request): #confirmation function. Takes request
    if request.method == 'POST': #if the form is entered(if yes delete is selected)
        form = ProductForm(request.POST or None) #grab all of the data from product form and pass to form variable
        if form.is_valid(): #if everything on the form is correct/valid
            form.delete() #then delete record
            return redirect('admin_console') #afterward return to admin_console
    else:
        return redirect('admin_console') #if anything above is not true, return to admin_console

def createRecord (request): #function create record taking in a request object
    form = ProductForm(request.POST or None) #variable to take all the info from productform or if they not provide none
    if form.is_valid(): #check to see if form is valid/fields filled correctly
        form.save() #if valid save it
        return redirect('admin_console') #when done saving, take user back to admin page
    else: #if not
        print(form.errors) #print errors for fields that need to be corrected
        form = ProductForm() #create empty form and save it in form variable
    context = { # then pass it back
        'form': form, #as a dictionary
    }
    return render(request, 'products/createRecord.html', context) #return the request, go back to createRecord.html page, with empty form to fill out
